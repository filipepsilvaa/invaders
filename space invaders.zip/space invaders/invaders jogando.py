from PPlay.gameimage import GameImage
from PPlay.window import *
from PPlay.sprite import *

# Configurações do jogo
janela = Window(width=800, height=600)
janela.set_title("Space Invaders Filipe Pinto")
teclado = Window.get_keyboard()
fundo= GameImage("fundo game.webp")

# Nave do jogador
nave = Sprite("nave.png")
nave.set_position(janela.width // 2 - nave.width // 2, janela.height - nave.height)

#projetil
projetil = Sprite("tiro.png")
projeteis = []

# Loop principal do jogo
while True:
    janela.update()
    fundo.draw()

    # Movimento da nave
    if teclado.key_pressed("RIGHT"):
        nave.x += 4
    if teclado.key_pressed("LEFT"):
        nave.x -= 4

    #delimitando a tela
    if nave.x<=0:
        nave.x=0

    elif nave.x >= janela.width - nave.width:
        nave.x = janela.width - nave.width




    # Disparo de projéteis
    if teclado.key_pressed("SPACE"):
        projetil = Sprite("tiro.png")
        projetil.set_position(nave.x + nave.width // 2 - projetil.width // 2, nave.y - projetil.height)
        projeteis.append(projetil)
        projetil.draw()

    # Movimento dos projéteis
    for projetil in projeteis:
        projetil.y -= 4
        projetil.draw()

        if projetil.y < 0:
            projeteis.remove(projetil)


     # imagens
    nave.draw()


