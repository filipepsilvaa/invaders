from PPlay.gameimage import GameImage
from PPlay.mouse import Mouse
from PPlay.window import Window
from PPlay.sprite import *

# Inicialização da janela
janela = Window(width=800, height=600)
janela.set_title("Menu invaders Filipe Pinto")
fundo = GameImage("fundo menu.webp")

#imagens das opções do menu
jogar = GameImage("jogar.png")
dificuldade = GameImage("dificuldade.png")
#dificuldades
facil = GameImage("dif-facil.png")
medio = GameImage("dif-medio.png")
dificil = GameImage("dif-dificil.png")
ranking = GameImage("ranking.png")
sair = GameImage("sair.png")

#Posição das opções do menu
pos_x = janela.width//2 -16
pos_y = janela.height//2 - 58

#posicionar as opçoes
jogar.set_position(pos_x, pos_y)
dificuldade.set_position(pos_x, pos_y + 50)
ranking.set_position(pos_x, pos_y + 100)
sair.set_position(pos_x, pos_y + 150)

#teclas
mouse = Mouse()
teclado = Window.get_keyboard()

#chave para rodar
funcionar = True

while funcionar:

    #aba "jogar"
    if mouse.is_over_object(jogar) and mouse.is_button_pressed(1):
        janela_jogo = Window(width=800, height=600)
        janela_jogo.set_title("Janela do jogo")

        #o jogo rodará aqui futuramente
        while funcionar:

            janela = Window(width=800, height=600)
            janela.set_title("Space Invaders Filipe Pinto")
            teclado = Window.get_keyboard()
            fundo = GameImage("fundo game.webp")

            # Nave do jogador
            nave = Sprite("nave.png")
            nave.set_position(janela.width // 2 - nave.width // 2, janela.height - nave.height)

            # projetil
            projetil = Sprite("tiro.png")
            projeteis = []

            # Loop principal do jogo
            while True:
                janela.update()
                fundo.draw()

                # Movimento da nave
                if teclado.key_pressed("RIGHT"):
                    nave.x += 4
                if teclado.key_pressed("LEFT"):
                    nave.x -= 4

                # delimitando a tela
                if nave.x <= 0:
                    nave.x = 0

                elif nave.x >= janela.width - nave.width:
                    nave.x = janela.width - nave.width

                # Disparo de projéteis
                if teclado.key_pressed("SPACE"):
                    projetil = Sprite("tiro.png")
                    projetil.set_position(nave.x + nave.width // 2 - projetil.width // 2, nave.y - projetil.height)
                    projeteis.append(projetil)
                    projetil.draw()

                # Movimento dos projéteis
                for projetil in projeteis:
                    projetil.y -= 4
                    projetil.draw()

                    if projetil.y < 0:
                        projeteis.remove(projetil)

                # imagens
                nave.draw()

            if (teclado.key_pressed("ESC")):
                funcionar = False
            janela_jogo.update()

    #aba "dificuldade"
    elif mouse.is_over_object(dificuldade) and mouse.is_button_pressed(1):
        janela = Window(width=500, height=400)
        janela.set_title("Janela de dificuldade")

        pos_x = janela.width // 2
        pos_y = janela.height // 2 - 50

        # posicionar as opçoes
        facil.set_position(pos_x, pos_y)
        medio.set_position(pos_x, pos_y + 50)
        dificil.set_position(pos_x, pos_y + 100)

        while funcionar:

            if (teclado.key_pressed("ESC")):
                funcionar = False
            janela.update()


    elif mouse.is_over_object(ranking) and mouse.is_button_pressed(1):
        print("Nada por aqui")

    elif mouse.is_over_object(sair) and mouse.is_button_pressed(1):
        print("Saindo do jogo")
        funcionar = False

    #imagens
    fundo.draw()
    jogar.draw()
    dificuldade.draw()
    ranking.draw()
    sair.draw()
    janela.update()

janela.close()
