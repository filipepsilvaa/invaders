'''from PPlay.window import *
from pplay.sprite import *
from pplay.gameimage import *
from pplay.keyboard import Keyboard



#janela do game
janela = Window(width= 600, height=500)
janela.set_title("menu invaders")
fundo = GameImage("fundo menu.webp")
fundo.draw()

#teclado
teclado = Window.get_keyboard()

while True:

    #voltar



    #updates
    janela.update()


'''



from PPlay.gameimage import GameImage
from PPlay.window import *

# Configurações do jogo
janela = Window(800, 600)
janela.set_title("Space Invaders Filipe Pinto")
teclado = Window.get_keyboard()
fundo= GameImage("fundo game.webp")

# Nave do jogador
nave = GameImage("nave.png")
nave.set_position(janela.width // 2 - nave.width // 2, janela.height - nave.height)

'''# Inimigos
inimigos = []
for i in range(5):
    inimigo = GameImage("enemy.png")
    inimigo.set_position(i * 150, 50)
    inimigos.append(inimigo)'''

# Projéteis
projeteis = []

# Loop principal do jogo
while True:
    janela.update()

    # Movimento da nave
    if teclado.key_pressed("RIGHT"):
        nave.x += 4
    if teclado.key_pressed("LEFT"):
        nave.x -= 4
    fundo.draw()
    nave.draw()



    # Disparo de projéteis
    if teclado.key_pressed("SPACE"):
        projetil = GameImage("tiro.png")
        projetil.set_position(nave.x + nave.width // 2 - projetil.width // 2, nave.y - projetil.height)
        projeteis.append(projetil)


    # Movimento dos projéteis
    for projetil in projeteis:
        projetil.y -= 4
        projetil.draw()
        if projetil.y < 0:
            projeteis.remove(projetil)
            fundo.draw()





    # Movimento dos inimigos
    '''for inimigo in inimigos:
        inimigo.x += 2
        inimigo.draw()'''



    # Verifica se o jogador perdeu o jogo
    '''for inimigo in inimigos:
        if inimigo.y + inimigo.height >= janela.height:
            janela.draw_text("Game Over", janela.width // 2 - 100, janela.height // 2, size=30, color=(255, 0, 0))
            janela.update()
            janela.delay(2000)
            janela.close()
            exit()

    # Verifica se o jogador venceu o jogo
    if not inimigos:
        janela.draw_text("Você Venceu!", janela.width // 2 - 100, janela.height // 2, size=30, color=(0, 255, 0))
        janela.update()
        janela.delay(2000)
        janela.close()
        exit()'''

