from PPlay.window import *
from PPlay.sprite import *
from PPlay.gameimage import *
from PPlay.keyboard import *

window = Window(width=800, height=600)
window.set_title('Space Invaders')

nave = Sprite("nave.png")
nave.x = window.width / 2 - nave.width / 2
nave.y = window.height - 100


controle = window.get_keyboard()

velN = 300
velShoot = 500

tiro = Sprite("tiro.png")
show_shoot = False

balayspeed = -1000
balas = []
tiro_delay = 0.25
tiro_tick = tiro_delay
tiro_copy = 0

#atirar


while True:
    window.set_background_color((0, 0, 0))
    nave.draw()

    tiro_tick += window.delta_time()
    if controle.key_pressed("SPACE"):
        if tiro_tick >  tiro_delay:
            bala = Sprite("tiro.png")
            bala.set_position((nave.x+(nave.width/2)-(bala.width/2)), (nave.y-bala.height))
            balas.append(bala)
            tiro_tick = 0
    for b in balas:
        if b.y<=0:
            balas.remove(b)
        b.move_y(balayspeed * window.delta_time())
        b.draw()

    if (controle.key_pressed("left")):
        nave.x -= velN * window.delta_time()
    elif (controle.key_pressed("right")):
        nave.x += velN * window.delta_time()
    if (nave.x <= 0):
        nave.x = 0
    if (nave.x >= window.width - nave.width):
        nave.x = window.width - nave.width



    window.update()